import requests

def hit_sender(card,message,chat_id):
    bot_token = '5744942358:AAGnTrdWKJFCt0gmt41vGaoBPP6sQhjQz2Y'
    url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
    data = {'chat_id': chat_id, 'text': message}
    requests.post(url, data=data)
