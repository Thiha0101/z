# Stripe-CC-Checker
A Python Terminal Based CC Checker Script. Rate Limit bypassed.

You need your own sk keys to check cards. 

Run : 
```
pip install -r requirements.txt 
python main.py
```

Change : 
> bot_token in extra.py

> '766109755' with your telegram id in main.py line 57 and 66 if so hits will be delivered to your inbox

Usage : 
> Enter a file path your credit cards are located. You can drag and drop too


> Enter a secret key, you can get alot of leaked keys at @heckerdrops on telegram


> Enter amount. If your amount is 1usd then you put 100


> Enter a currency supported by stripe. Like : usd, inr, gbp, eur
