
#https://my.telegram.org/
API_ID = 22843789
# https://my.telegram.org/
API_HASH = "cea69113320bdfbd6a8ae153d4342184"

# from file SESSION.py
SESSION = "BQFckY0ApZqqM7PnjNEdTdgcUEEQqS_pdQUWTTYA1-HjcaIxbdE6F9DKT91fOA_GoCleqfGS4575DSg4WYHd8G0P5t0okO5DoTHqGQa_5YDo-PHxRL6kaWSuE2U1KcdoArhRg-iZ-JheDS91QPUMsKLp4EG8_8t8uzCX-a5mdPryFA6tdHPxZam3pvxIWtLgsU8agtesMrjcUsciomM4Ooc71NwQH_W_kdlU1b5uZQE_KT9mIyfGV0B5u8_hc6AJ3jVM4qmw3hFXc5DkXbh8spT7H-JH7oI3fY7viDQYM8q53beYLIJ0ZgEdGTWsUqnEAph3VQukqxHwekhxhBOR3KyfPsnLlgAAAABoL-fBAA"

chanel = "Never_Dead0110"

# from @BotFather
TOKEN = "6072028188:AAH0BnXbRbegPQLIJdnykCEbU6ufbhzupEI"